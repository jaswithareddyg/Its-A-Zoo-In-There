//
//  ViewController.swift
//  It's a Zoo in There
//
//  Created by Jaswitha Reddy Guntaka on 1/14/23.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    @IBOutlet var scrollView: UIScrollView!
    @IBOutlet var label: UILabel!
    
    var animals = [Animal]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        scrollView.delegate = self
        scrollView.contentSize = CGSize(width: 1200, height: 600)
        
        let fox = Animal(name: "Vul", species: "Fox", age: 1, image: UIImage(named: "smiling-cute-funny-fox-pun")!, soundPath: "fox_sound-1.mp3")
        let squirrel = Animal(name: "Can", species: "Squirrel", age: 5, image: UIImage(named: "chocolate-chip-squirrel-shendl-rewitzky")!, soundPath: "red_squirrel_chatter-78251.mp3")
        let panda = Animal(name: "Min", species: "Red Panda/Lesser Panda", age: 3, image: UIImage(named: "red-panda-cub-first-vet-visit-Paradise-wildlife-park-in-Hertfordshire-SWNS-1024x565")!, soundPath: "SnapSave.io - Red Panda Sound, Red Panda Video  , animal videos 4k (128 kbps).mp3")
        
        animals.append(fox)
        animals.append(squirrel)
        animals.append(panda)
        
        animals.shuffle()
        
        
        var count = 0
        for i in animals{
            let button = UIButton(type: .system)
            let imageView = UIImageView()
            
            imageView.contentMode = .scaleAspectFit
            imageView.image = i.image
            imageView.frame = CGRect(x: 0, y: 0, width: 400, height: 600)
            scrollView.addSubview(imageView)
            print(i.image)
            
            var config = UIButton.Configuration.filled()
            config.cornerStyle = .dynamic
            config.title = i.name
            config.baseBackgroundColor = .red
            
            button.configuration = config
            button.frame = CGRect(x: 280 + (count * 390), y: 20, width: 100, height: 40)
            button.tag = count
            scrollView.addSubview(button)
            count += 1
        }
        func buttonTapped(_ button: UIButton){
            var flag = 0
            for i in animals{
                if (button.tag == 0){
                    flag = 1
                }
                else if (button.tag == 1){
                    flag = 1
                }
                else if (button.tag == 2){
                    flag = 1
                }
                
                if (flag == 1){
                    let alert = UIAlertController(title: "Alert",
                                                  message: i.description, preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "Play Sound", style: .default, handler: {action in
                                                    print("You are good!")}
                    ))
                    alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                    self.present(alert, animated: true)
                    flag = 0
                    
                }
            }
        }
    }
}

